package chair.utility.contract;

public class PCmemberRelationStatus {
    public final static String accepted = "accepted";
    public final static String undealed = "undealed";
    public final static String rejected = "rejected";
}
