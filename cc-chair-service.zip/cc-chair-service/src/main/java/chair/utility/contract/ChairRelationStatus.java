package chair.utility.contract;

public class ChairRelationStatus {
    public final static String approved = "approved";
    public final static String queuing = "queuing";
    public final static String rejected = "rejected";
}
